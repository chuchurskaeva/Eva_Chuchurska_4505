﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace EvaZad2.Data.Migrations
{
    public partial class Updating : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "ClientId",
                table: "CarRentals",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_CarRentals_ClientId",
                table: "CarRentals",
                column: "ClientId");

            migrationBuilder.AddForeignKey(
                name: "FK_CarRentals_Clients_ClientId",
                table: "CarRentals",
                column: "ClientId",
                principalTable: "Clients",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_CarRentals_Clients_ClientId",
                table: "CarRentals");

            migrationBuilder.DropIndex(
                name: "IX_CarRentals_ClientId",
                table: "CarRentals");

            migrationBuilder.DropColumn(
                name: "ClientId",
                table: "CarRentals");
        }
    }
}
