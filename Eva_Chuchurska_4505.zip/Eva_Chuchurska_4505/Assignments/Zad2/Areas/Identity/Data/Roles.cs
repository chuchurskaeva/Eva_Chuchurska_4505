﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EvaZad2.Areas.Identity.Data
{
    public enum Roles
    {
        Admin, 
        Moderator,
        User
    }
}
