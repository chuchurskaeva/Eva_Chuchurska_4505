﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using EvaZad2.Data;
using EvaZad2.Models;

namespace EvaZad2.Controllers
{
    public class ClientCarsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ClientCarsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: ClientCars
        public async Task<IActionResult> Index()
        {
            var applicationDbContext = _context.ClientCar.Include(c => c.Car).Include(c => c.Client);
            return View(await applicationDbContext.ToListAsync());
        }

        // GET: ClientCars/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var clientCar = await _context.ClientCar
                .Include(c => c.Car)
                .Include(c => c.Client)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (clientCar == null)
            {
                return NotFound();
            }

            return View(clientCar);
        }

        // GET: ClientCars/Create
        public IActionResult Create()
        {
            ViewData["CarId"] = new SelectList(_context.CarRentals, "Id", "Manufacturer");
            ViewData["ClientId"] = new SelectList(_context.Clients, "Id", "Name");
            return View();
        }

        // POST: ClientCars/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,ClientId,CarId")] ClientCar clientCar)
        {
            if (ModelState.IsValid)
            {
                _context.Add(clientCar);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["CarId"] = new SelectList(_context.CarRentals, "Id", "Manufacturer", clientCar.CarId);
            ViewData["ClientId"] = new SelectList(_context.Clients, "Id", "Name", clientCar.ClientId);
            return View(clientCar);
        }

        // GET: ClientCars/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var clientCar = await _context.ClientCar.FindAsync(id);
            if (clientCar == null)
            {
                return NotFound();
            }
            ViewData["CarId"] = new SelectList(_context.CarRentals, "Id", "Manufacturer", clientCar.CarId);
            ViewData["ClientId"] = new SelectList(_context.Clients, "Id", "Name", clientCar.ClientId);
            return View(clientCar);
        }

        // POST: ClientCars/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,ClientId,CarId")] ClientCar clientCar)
        {
            if (id != clientCar.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(clientCar);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ClientCarExists(clientCar.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["CarId"] = new SelectList(_context.CarRentals, "Id", "Manufacturer", clientCar.CarId);
            ViewData["ClientId"] = new SelectList(_context.Clients, "Id", "Name", clientCar.ClientId);
            return View(clientCar);
        }

        // GET: ClientCars/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var clientCar = await _context.ClientCar
                .Include(c => c.Car)
                .Include(c => c.Client)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (clientCar == null)
            {
                return NotFound();
            }

            return View(clientCar);
        }

        // POST: ClientCars/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var clientCar = await _context.ClientCar.FindAsync(id);
            _context.ClientCar.Remove(clientCar);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ClientCarExists(int id)
        {
            return _context.ClientCar.Any(e => e.Id == id);
        }
    }
}
