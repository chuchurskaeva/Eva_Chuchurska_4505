﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace EvaZad2.Models
{
    public class Client
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string Name { get; set; }
        [Required]
        [Range(18, 70,
        ErrorMessage = "Value for {0} must be between {1} and {2}.")]
        public int Age { get; set; }
        [Required]
        public string PassportNumber { get; set; }
        public ICollection<CarRental> RentedCars { get; set; }
    }
}
