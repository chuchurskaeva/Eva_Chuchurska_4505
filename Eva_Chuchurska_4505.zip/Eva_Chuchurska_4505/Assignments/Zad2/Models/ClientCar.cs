﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace EvaZad2.Models
{
    public class ClientCar
    {
        [Key]
        public int Id { get; set; }
        public Client Client { get; set; }
        public int ClientId { get; set; }
        public CarRental Car { get; set; }
        public int CarId { get; set; }
    }
}
