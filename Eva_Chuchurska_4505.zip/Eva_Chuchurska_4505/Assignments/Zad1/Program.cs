﻿using System;

namespace EvaZad1
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] students = new int[8];

            students[0] = 10;
            students[1] = 8;
            students[2] = 9;
            students[3] = 12;
            students[4] = 15;
            students[5] = 7;
            students[6] = 7;
            students[7] = 8;

            int youngest = students[0];
            int oldest = students[0];
            int counterYoungest = 0;
            int counterOldest = 0;

            for (int i = 0; i < students.Length; i++)
            {
                if (students[i] > oldest)
                {
                    oldest = students[i];
                    counterOldest++;
                }
            }

            for (int i = 0; i < students.Length; i++)
            {
                if (students[i] < youngest)
                {
                    youngest = students[i];
                    counterYoungest++;
                }
            }


            Console.WriteLine("Youngest student in the group is: " + youngest);
            if (counterYoungest > 1)
            {
                Console.WriteLine("There are " + counterYoungest + " at that age in the group");
            }

            Console.WriteLine("Oldest student in the group is: " + oldest);
            if (counterOldest > 1)
            {
                Console.WriteLine("There are " + counterOldest + " at that age in the group");
            }
        }
    }
}
